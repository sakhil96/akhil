export type SiteBadge = {
  label: string;
  tone?: 'accent' | 'muted' | 'success' | 'warning';
};

export type TerminalCommand = {
  command: string;
  description: string;
  output: string[];
};

export type CaseStudyPreview = {
  slug: string;
  title: string;
  subtitle: string;
  summary: string;
  tags: string[];
  href: string;
};

export const site = {
  meta: {
    title: 'Akhil Adapala — AI Inference Control Room',
    description:
      'Award-winning product designer and senior software engineer building AI-first platforms with product-grade execution.',
    siteUrl: 'https://your-domain.com',
  },
  profile: {
    name: 'Akhil Adapala',
    role: 'Senior Software Engineer, AI Tech',
    location: 'Hyderabad, India',
    email: 'akhilsambasiva@gmail.com',
    imageUrl: '/profile.jpg',
    imageAlt: 'Akhil Adapala portrait',
    links: {
      linkedin: 'https://www.linkedin.com/in/akhil-adapala-57b6bba5/',
      github: 'https://github.com/sakhil96',
    },
  },
  hero: {
    headline: 'Control Room for AI Inference + Product Thinking',
    subheadline:
      'Award-winning product designer and senior software engineer shipping AI-first platforms with product-grade execution.',
    badges: [
      { label: 'Cursor Hackathon Winner', tone: 'accent' },
      { label: 'AI Adapt Hackathon Winner', tone: 'success' },
      { label: 'PayPal × Google Cloud Summit', tone: 'muted' },
      { label: 'Top ___', tone: 'warning' },
    ],
  },
  sections: [
    { id: 'system', label: 'System Snapshot' },
    { id: 'terminal', label: 'Terminal' },
    { id: 'wins', label: 'Trophy Cabinet' },
    { id: 'case-studies', label: 'Case Studies' },
    { id: 'projects', label: 'Projects' },
    { id: 'experience', label: 'Experience' },
    { id: 'skills', label: 'Skills' },
    { id: 'contact', label: 'Contact' },
  ],
  systemSnapshot: [
    { label: 'Experience', value: '8+ years' },
    { label: 'Focus', value: 'AI inference platforms' },
    { label: 'Cloud', value: 'GCP + Kubernetes' },
    { label: 'Languages', value: 'Java, TypeScript, SQL' },
  ],
  terminal: {
    prompt: 'control-room',
    commands: [
      {
        command: 'help',
        description: 'List available commands',
        output: [
          'wins — trophy highlights',
          'smartwealth — AI Adapt case',
          'cursor — Cursor Hackathon case',
          'projects — platform builds',
          'stack — core skills',
          'contact — reach me',
        ],
      },
      {
        command: 'wins',
        description: 'Show hackathon wins',
        output: [
          'Cursor Hackathon — 1st Place (Team Busters)',
          'Cursor Hackathon — 2nd Place (Engineering Impact Platform)',
          'AI Adapt Hackathon — SmartWealth',
        ],
      },
      {
        command: 'smartwealth',
        description: 'Show SmartWealth summary',
        output: [
          'AI-powered investing inside PayPal.',
          'One tap. $1 minimum. ETFs, crypto, high-yield savings.',
          'Hackathon concept/pitch; not an official product announcement.',
        ],
      },
      {
        command: 'cursor',
        description: 'Show Cursor Hackathon summary',
        output: [
          'Built AI-first workflows that ship fast.',
          'Two podium wins in one hackathon.',
          'Case study: /case-studies/cursor-hackathon',
        ],
      },
      {
        command: 'projects',
        description: 'Show selected projects',
        output: [
          'Inference Control Plane — low-latency scoring platform',
          'MCP Tooling — developer workflows for AI ops',
          'Risk Signal Observatory — model health + drift insights',
        ],
      },
      {
        command: 'stack',
        description: 'Show core stack',
        output: [
          'Java, TypeScript, Spring Boot, Next.js',
          'GKE, Kubernetes, Docker',
          'MLOps pipelines, monitoring, guardrails',
        ],
      },
      {
        command: 'contact',
        description: 'Show contact info',
        output: [
          'Email: akhilsambasiva@gmail.com',
          'LinkedIn: linkedin.com/in/akhil-adapala-57b6bba5',
          'GitHub: github.com/sakhil96',
        ],
      },
    ] satisfies TerminalCommand[],
  },
  trophies: [
    {
      title: 'Cursor Hackathon — 1st Place (Team Busters)',
      tags: ['AI tooling', 'Developer velocity'],
      bullets: [
        'Problem: teams lose time stitching AI workflows.',
        'Built: a fast control room that unified prompt → build → deploy.',
        'Result: shipped a crisp demo that won 1st place.',
      ],
      cta: { label: 'Read case study →', href: '/case-studies/cursor-hackathon' },
    },
    {
      title: 'Cursor Hackathon — 2nd Place (Engineering Impact Platform)',
      tags: ['Platform analytics', 'Decision support'],
      bullets: [
        'Problem: impact visibility was fragmented across systems.',
        'Built: a unified engineering cockpit for impact signals.',
        'Result: clearer prioritization with platform-grade UX.',
      ],
      cta: { label: 'Read case study →', href: '/case-studies/cursor-hackathon' },
    },
    {
      title: 'AI Adapt Hackathon — SmartWealth',
      tags: ['Fintech', 'AI product'],
      bullets: [
        'Problem: investing feels complex and out of reach.',
        'Built: AI-guided investing inside PayPal with $1 entry.',
        'Result: a vision for trusted, accessible wealth building.',
      ],
      cta: { label: 'Read case study →', href: '/case-studies/smartwealth' },
    },
  ],
  caseStudies: [
    {
      slug: 'cursor-hackathon',
      title: 'Cursor Hackathon',
      subtitle: '1st & 2nd Place',
      summary:
        'Two winning builds that turn AI workflows into platform-grade execution.',
      tags: ['AI tooling', 'Platform UX', 'Hackathon'],
      href: '/case-studies/cursor-hackathon',
    },
    {
      slug: 'smartwealth',
      title: 'SmartWealth',
      subtitle: 'AI Adapt Hackathon Winner',
      summary:
        'A one-tap investing experience leveraging the world’s richest money-movement signal.',
      tags: ['Fintech', 'AI product', 'Vision'],
      href: '/case-studies/smartwealth',
    },
  ] satisfies CaseStudyPreview[],
  projects: [
    {
      name: 'Inference Control Plane',
      description:
        'Low-latency orchestration for real-time risk scoring and model execution.',
      tags: ['Platform', 'Reliability', 'Latency'],
    },
    {
      name: 'MCP Tooling',
      description:
        'Developer workflows that standardize onboarding, config validation, and deployments.',
      tags: ['Tooling', 'Ops', 'Automation'],
    },
    {
      name: 'Signal Observatory',
      description:
        'Monitoring and guardrails for model health, drift, and incident response.',
      tags: ['MLOps', 'Observability', 'Safety'],
    },
  ],
  experience: [
    {
      role: 'Senior Software Engineer, AI Tech',
      company: 'PayPal',
      period: 'Dec 2022 — Present',
      highlights: [
        'Build AI inference platforms for real-time risk scoring at scale.',
        'Drive cloud-native migration with audit/shadow validation and safe rollouts.',
        'Deliver platform tooling that speeds up model onboarding.',
      ],
    },
    {
      role: 'Senior Software Engineer',
      company: 'Oracle',
      period: 'Nov 2021 — Nov 2022',
      highlights: [
        'Shipped full-stack features for enterprise marketing workflows.',
        'Built reliable Java services and responsive web modules.',
      ],
    },
    {
      role: 'Software Engineer',
      company: 'TCS',
      period: 'Dec 2017 — Oct 2021',
      highlights: [
        'Delivered public-sector workflows with secure, role-based UX.',
        'Owned end-to-end delivery across backend and UI modules.',
      ],
    },
  ],
  skills: [
    {
      group: 'Product + Design',
      items: ['Product strategy', 'System thinking', 'UX flows', 'Prototyping'],
    },
    {
      group: 'Frontend',
      items: ['Next.js', 'TypeScript', 'JavaScript', 'HTML/CSS', 'Oracle JET', 'jQuery'],
    },
    {
      group: 'Backend + MLOps',
      items: [
        'Java',
        'Spring Boot',
        'Hibernate/JPA',
        'REST APIs',
        'SQL',
        'MySQL',
        'ActiveMQ',
        'Nginx',
        'Gradle',
        'Git',
      ],
    },
    {
      group: 'Cloud + DevOps',
      items: ['GCP', 'GKE', 'Kubernetes', 'Docker', 'Observability'],
    },
  ],
  cursorCaseStudy: {
    title: 'Cursor Hackathon — 1st & 2nd Place',
    subtitle:
      'Two award-winning builds that made AI workflows feel effortless and scalable.',
    teams: [
      {
        name: 'Team Busters — 1st Place',
        problem:
          'AI workflows were fragmented and slow to operationalize across teams.',
        approach:
          'Designed a control-room experience that stitched prompts, assets, and deployment signals into one flow.',
        outcome:
          'Delivered a cohesive demo that showcased speed, clarity, and platform readiness.',
        why: 'Great AI products need a command center—this proved the model.',
      },
      {
        name: 'Engineering Impact Platform — 2nd Place',
        problem:
          'Engineering impact data was scattered, making prioritization unclear.',
        approach:
          'Built a unified cockpit for impact signals with clear ranking and storytelling.',
        outcome:
          'Improved decision velocity with a single source of truth UX.',
        why: 'Teams move faster when impact is visible and trusted.',
      },
    ],
    builtWithCursor: [
      'Generate an architecture that maps signals → inference → outcome.',
      'Draft a clean UX flow for command-center navigation.',
      'Refine copy to be executive-level and launch-ready.',
    ],
  },
  smartwealthCaseStudy: {
    title: 'SmartWealth',
    subtitle: 'AI Adapt Hackathon Winner',
    hero:
      'SmartWealth transforms a strength only PayPal possesses: the world’s richest financial signal — how money moves.',
    uniqueAdvantage:
      'Money-movement intelligence enables personalization that new fintechs cannot match.',
    thesis:
      'Evolve from payments utility → most accessible wealth platform; shift from transactions → lifelong financial relationships.',
    productVision:
      'AI-powered investing inside PayPal—frictionless, intuitive, accessible. One tap. $1 minimum. ETFs, crypto, high-yield savings—inside the platform people already trust.',
    experienceJourney: [
      'Discover: See a personalized “wealth snapshot” from your cash flow.',
      'Decide: Pick a goal with a simple risk slider and clear outcomes.',
      'Invest: One tap to start at $1 with instant confirmation.',
      'Grow: Ongoing guidance with guardrails and transparent reasoning.',
    ],
    aiApproach: [
      'Personalization from high-signal transaction patterns.',
      'Risk calibration tuned to user goals and volatility comfort.',
      'Guardrails to prevent overexposure and harmful advice.',
      'Explainability and monitoring for trust and compliance.',
    ],
    whyPayPalWins: [
      '435M+ users → built-in distribution, effectively zero CAC.',
      '$1.6T+ payment volume → a data advantage unmatched.',
      '25 years of global trust → a foundation no new fintech can recreate.',
    ],
    role: [
      'Owned the pitch narrative and product vision.',
      'Designed the experience flow and demo story.',
      'Outlined system concept with AI safety framing.',
    ],
    nextBuild: [
      'MVP: goal-based onboarding, risk slider, starter ETF bundles.',
      'Safety checklist: suitability, disclosures, drift monitoring.',
      'Metrics: activation, retention, contribution rate, trust NPS.',
    ],
    disclaimer: 'Hackathon concept/pitch; not an official product announcement.',
  },
  contact: {
    headline: 'Let’s build the next control room.',
    subheadline:
      'Open to collaborations on AI-first systems, product strategy, and platform UX.',
  },
};
