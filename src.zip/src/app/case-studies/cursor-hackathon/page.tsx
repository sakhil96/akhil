import Link from 'next/link';
import { Badge } from '@/components/Badge';
import { Card } from '@/components/Card';
import { CTAButton } from '@/components/CTAButton';
import { SectionHeading } from '@/components/SectionHeading';
import { site } from '@/lib/site';

export const metadata = {
  title: `${site.cursorCaseStudy.title} — Case Study`,
  description: site.cursorCaseStudy.subtitle,
};

export default function CursorHackathonPage() {
  const caseStudy = site.cursorCaseStudy;

  return (
    <main className="mx-auto flex max-w-4xl flex-col gap-12 px-4 pb-20 pt-16 sm:px-6 lg:px-8">
      <div className="flex items-center justify-between text-sm text-muted">
        <Link href="/" className="hover:text-text">
          ← Back to home
        </Link>
        <Badge label="Cursor Hackathon" tone="accent" />
      </div>

      <section className="flex flex-col gap-4">
        <h1 className="font-display text-4xl">{caseStudy.title}</h1>
        <p className="text-muted">{caseStudy.subtitle}</p>
      </section>

      <section className="grid gap-6">
        {caseStudy.teams.map((team) => (
          <Card key={team.name} className="flex flex-col gap-4">
            <div>
              <h2 className="text-2xl font-semibold">{team.name}</h2>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <h3 className="text-sm font-semibold text-text">Problem</h3>
                <p className="text-sm text-muted">{team.problem}</p>
              </div>
              <div>
                <h3 className="text-sm font-semibold text-text">Approach</h3>
                <p className="text-sm text-muted">{team.approach}</p>
              </div>
              <div>
                <h3 className="text-sm font-semibold text-text">Outcome</h3>
                <p className="text-sm text-muted">{team.outcome}</p>
              </div>
              <div>
                <h3 className="text-sm font-semibold text-text">Why it matters</h3>
                <p className="text-sm text-muted">{team.why}</p>
              </div>
            </div>
          </Card>
        ))}
      </section>

      <section className="flex flex-col gap-6">
        <SectionHeading
          eyebrow="Built with Cursor"
          title="Workflow prompts"
          description="Example prompts that shaped the builds (public-safe)."
        />
        <Card className="space-y-3 text-sm text-muted">
          {caseStudy.builtWithCursor.map((prompt) => (
            <div key={prompt} className="rounded-xl border border-white/10 bg-white/5 p-3">
              {prompt}
            </div>
          ))}
        </Card>
      </section>

      <CTAButton href="/#wins" label="Back to trophy cabinet" variant="ghost" />
    </main>
  );
}
