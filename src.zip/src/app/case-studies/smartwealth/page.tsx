import Link from 'next/link';
import { Badge } from '@/components/Badge';
import { Card } from '@/components/Card';
import { SectionHeading } from '@/components/SectionHeading';
import { site } from '@/lib/site';

export const metadata = {
  title: `${site.smartwealthCaseStudy.title} — Case Study`,
  description: site.smartwealthCaseStudy.subtitle,
};

export default function SmartWealthPage() {
  const caseStudy = site.smartwealthCaseStudy;

  return (
    <main className="mx-auto flex max-w-4xl flex-col gap-12 px-4 pb-20 pt-16 sm:px-6 lg:px-8">
      <div className="flex items-center justify-between text-sm text-muted">
        <Link href="/" className="hover:text-text">
          ← Back to home
        </Link>
        <Badge label="AI Adapt Hackathon" tone="success" />
      </div>

      <section className="flex flex-col gap-4">
        <h1 className="font-display text-4xl">{caseStudy.title}</h1>
        <p className="text-muted">{caseStudy.subtitle}</p>
        <p className="text-lg text-text">{caseStudy.hero}</p>
      </section>

      <section className="grid gap-6">
        <Card className="space-y-3">
          <SectionHeading title="The unique advantage" />
          <p className="text-sm text-muted">{caseStudy.uniqueAdvantage}</p>
        </Card>
        <Card className="space-y-3">
          <SectionHeading title="The big thesis" />
          <p className="text-sm text-muted">{caseStudy.thesis}</p>
        </Card>
        <Card className="space-y-3">
          <SectionHeading title="The product vision" />
          <p className="text-sm text-muted">{caseStudy.productVision}</p>
        </Card>
      </section>

      <section className="flex flex-col gap-6">
        <SectionHeading title="Experience design" />
        <Card className="space-y-3 text-sm text-muted">
          {caseStudy.experienceJourney.map((step) => (
            <div key={step} className="flex items-start gap-2">
              <span className="mt-1 h-1.5 w-1.5 rounded-full bg-accent" />
              <span>{step}</span>
            </div>
          ))}
        </Card>
      </section>

      <section className="flex flex-col gap-6">
        <SectionHeading title="AI approach (high-level)" />
        <Card className="space-y-3 text-sm text-muted">
          {caseStudy.aiApproach.map((item) => (
            <div key={item} className="flex items-start gap-2">
              <span className="mt-1 h-1.5 w-1.5 rounded-full bg-accent" />
              <span>{item}</span>
            </div>
          ))}
        </Card>
      </section>

      <section className="flex flex-col gap-6">
        <SectionHeading title="Why PayPal wins" description="Approx / public reporting." />
        <Card className="space-y-3 text-sm text-muted">
          {caseStudy.whyPayPalWins.map((item) => (
            <div key={item} className="flex items-start gap-2">
              <span className="mt-1 h-1.5 w-1.5 rounded-full bg-accent" />
              <span>{item}</span>
            </div>
          ))}
        </Card>
      </section>

      <section className="flex flex-col gap-6">
        <SectionHeading title="My role" />
        <Card className="space-y-3 text-sm text-muted">
          {caseStudy.role.map((item) => (
            <div key={item} className="flex items-start gap-2">
              <span className="mt-1 h-1.5 w-1.5 rounded-full bg-accent" />
              <span>{item}</span>
            </div>
          ))}
        </Card>
      </section>

      <section className="flex flex-col gap-6">
        <SectionHeading title="What I’d build next" />
        <Card className="space-y-3 text-sm text-muted">
          {caseStudy.nextBuild.map((item) => (
            <div key={item} className="flex items-start gap-2">
              <span className="mt-1 h-1.5 w-1.5 rounded-full bg-accent" />
              <span>{item}</span>
            </div>
          ))}
        </Card>
      </section>

      <Card className="border border-warning/30 bg-warning/10 text-sm text-warning">
        {caseStudy.disclaimer}
      </Card>
    </main>
  );
}
