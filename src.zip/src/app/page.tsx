import Link from 'next/link';
import { Badge } from '@/components/Badge';
import { Card } from '@/components/Card';
import { CTAButton } from '@/components/CTAButton';
import { CopyButton } from '@/components/CopyButton';
import { Reveal } from '@/components/Reveal';
import { SectionHeading } from '@/components/SectionHeading';
import { Terminal } from '@/components/Terminal';
import { TrophyCard } from '@/components/TrophyCard';
import { site } from '@/lib/site';

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <main className="mx-auto flex max-w-6xl flex-col gap-24 px-4 pb-24 pt-16 sm:px-6 lg:px-8">
        <section className="grid gap-10 pt-10 lg:grid-cols-[1.2fr_0.8fr] lg:items-center">
          <div className="flex flex-col gap-10">
            <div className="flex flex-wrap items-center gap-3 text-xs text-muted">
              <span className="rounded-full border border-accent/40 px-3 py-1 text-accent">
                Signal → Inference → Outcome
              </span>
              <span>{site.profile.location}</span>
            </div>
            <div className="flex flex-col gap-6">
              <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl">
                {site.profile.name}
                <span className="block text-gradient">{site.hero.headline}</span>
              </h1>
              <p className="text-sm uppercase tracking-[0.2em] text-muted">
                {site.profile.role}
              </p>
              <p className="max-w-2xl text-base text-muted sm:text-lg">
                {site.hero.subheadline}
              </p>
              <div className="flex flex-wrap gap-3">
                {site.hero.badges.map((badge) => (
                  <Badge key={badge.label} label={badge.label} tone={badge.tone} />
                ))}
              </div>
            </div>
            <div className="flex flex-wrap gap-4">
              <CTAButton href="#case-studies" label="View case studies" />
              <CTAButton href="#contact" label="Get in touch" variant="ghost" />
            </div>
          </div>
          <div className="relative mx-auto w-full max-w-sm">
            <div className="absolute -inset-6 rounded-[32px] border border-accent/20 bg-accent/10 blur-2xl" />
            <div className="absolute -left-8 top-12 h-24 w-24 rounded-full border border-accent/30 bg-accent/10 blur-xl" />
            <div className="relative overflow-hidden rounded-[28px] border border-white/10 bg-surface transition duration-300 hover:-translate-y-1 hover:border-accent/40">
              <div className="absolute right-6 top-6 z-10 rounded-full border border-white/20 bg-black/40 px-3 py-1 text-xs text-muted">
                Inference Operator
              </div>
              <div className="absolute left-6 top-6 z-10 text-[10px] uppercase tracking-[0.3em] text-accent/80">
                Signal Mask
              </div>
              <div className="absolute inset-0 bg-gradient-to-tr from-black/70 via-black/20 to-transparent" />
              <div className="absolute inset-0 opacity-35 [background-image:radial-gradient(circle_at_20%_20%,rgba(109,92,255,0.35),transparent_50%),radial-gradient(circle_at_80%_70%,rgba(69,211,255,0.25),transparent_55%)]" />
              <div className="absolute inset-0 opacity-25 [background-image:linear-gradient(to_right,rgba(255,255,255,0.08)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.08)_1px,transparent_1px)] [background-size:32px_32px]" />
              <div className="absolute inset-x-0 top-0 h-20 bg-gradient-to-b from-accent/15 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 h-28 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />
              <div className="absolute left-6 top-6 h-8 w-8 border-l border-t border-white/40" />
              <div className="absolute right-6 top-6 h-8 w-8 border-r border-t border-white/40" />
              <div className="absolute left-6 bottom-6 h-8 w-8 border-b border-l border-white/40" />
              <div className="absolute right-6 bottom-6 h-8 w-8 border-b border-r border-white/40" />
              <img
                src={site.profile.imageUrl}
                alt={site.profile.imageAlt}
                className="h-[420px] w-full object-cover saturate-110 contrast-105"
                loading="lazy"
              />
              <div className="absolute inset-0 scanlines">
                <div className="absolute inset-0 bg-[linear-gradient(120deg,rgba(109,92,255,0.6),rgba(69,211,255,0.25))] mix-blend-screen opacity-50" />
                <div className="absolute inset-0 [mask-image:linear-gradient(110deg,transparent_0%,transparent_48%,black_52%,black_100%)]">
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_40%,rgba(109,92,255,0.35),transparent_55%)]" />
                  <div className="absolute inset-0 opacity-35 [background-image:linear-gradient(to_right,rgba(255,255,255,0.12)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.12)_1px,transparent_1px)] [background-size:18px_18px]" />
                  <div className="absolute inset-0 opacity-60 [background-image:radial-gradient(circle_at_20%_30%,rgba(69,211,255,0.25),transparent_50%)]" />
                </div>
                <div className="absolute inset-0 [mask-image:linear-gradient(110deg,black_0%,black_48%,transparent_52%,transparent_100%)]">
                  <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/35" />
                </div>
                <div className="absolute left-1/2 top-0 h-full w-[2px] bg-gradient-to-b from-accent/0 via-accent/60 to-accent/0" />
                <div className="absolute left-1/2 top-0 h-full w-24 -translate-x-1/2 bg-gradient-to-r from-transparent via-accent/10 to-transparent" />
                <div className="absolute inset-y-0 left-0 w-[52%] ai-flicker">
                  <div className="absolute inset-0 bg-[linear-gradient(160deg,rgba(69,211,255,0.2),transparent)]" />
                  <div className="absolute inset-0 opacity-35 [background-image:linear-gradient(to_right,rgba(69,211,255,0.18)_1px,transparent_1px),linear-gradient(to_bottom,rgba(69,211,255,0.18)_1px,transparent_1px)] [background-size:14px_14px]" />
                  <div className="absolute inset-0 opacity-50 [background-image:linear-gradient(to_bottom,transparent_0%,rgba(69,211,255,0.18)_45%,transparent_55%)]" />
                </div>
              </div>
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent p-4 text-sm text-muted">
                Focused on platform UX, AI inference, and product clarity.
              </div>
            </div>
            <div className="pointer-events-none absolute -bottom-6 -right-6 h-32 w-32 rounded-full border border-accent/30 bg-accent/10 blur-xl" />
          </div>
        </section>

        <section id="system" className="flex flex-col gap-10">
          <SectionHeading
            eyebrow="System Snapshot"
            title="Platform-grade execution, product-first thinking."
            description="A quick glance at the signal surface I operate on."
          />
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {site.systemSnapshot.map((item) => (
              <Reveal key={item.label}>
                <Card className="flex flex-col gap-3">
                  <span className="text-xs uppercase tracking-[0.2em] text-muted">{item.label}</span>
                  <span className="text-xl font-semibold text-text">{item.value}</span>
                </Card>
              </Reveal>
            ))}
          </div>
          <Card className="border border-accent/30">
            <div className="flex flex-col gap-3">
              <Badge label="PayPal × Google Cloud Summit" tone="muted" />
              <p className="text-sm text-muted">
                Shared platform insights and modern cloud-native patterns for AI inference at scale.
                Public-safe, high-level, and focused on product outcomes.
              </p>
            </div>
          </Card>
        </section>

        <section id="terminal" className="flex flex-col gap-8">
          <SectionHeading
            eyebrow="Interactive"
            title="Control room terminal"
            description="Quick commands to explore wins, projects, and contact."
          />
          <Terminal />
        </section>

        <section id="wins" className="flex flex-col gap-10">
          <SectionHeading
            eyebrow="Trophy Cabinet"
            title="Hackathon wins with platform-grade execution."
            description="Problem → Build → Result, with no internal-only details."
          />
          <div className="grid gap-6 lg:grid-cols-3">
            {site.trophies.map((trophy) => (
              <Reveal key={trophy.title}>
                <TrophyCard {...trophy} />
              </Reveal>
            ))}
          </div>
        </section>

        <section id="case-studies" className="flex flex-col gap-10">
          <SectionHeading
            eyebrow="Case Studies"
            title="Deep dives on AI-first product strategy."
            description="Two flagship builds that show platform thinking and product execution."
          />
          <div className="grid gap-6 lg:grid-cols-2">
            {site.caseStudies.map((study) => (
              <Reveal key={study.slug}>
                <Card className="flex h-full flex-col gap-4">
                  <div className="flex flex-wrap gap-2">
                    {study.tags.map((tag) => (
                      <Badge key={tag} label={tag} tone="muted" />
                    ))}
                  </div>
                  <div>
                    <h3 className="text-2xl font-semibold">{study.title}</h3>
                    <p className="text-sm text-muted">{study.subtitle}</p>
                  </div>
                  <p className="text-sm text-muted">{study.summary}</p>
                  <CTAButton href={study.href} label="Read case study →" variant="ghost" />
                </Card>
              </Reveal>
            ))}
          </div>
        </section>

        <section id="projects" className="flex flex-col gap-10">
          <SectionHeading
            eyebrow="Projects"
            title="AI-first systems with a product spine."
            description="Platform-style builds that prioritize reliability and clarity."
          />
          <div className="grid gap-6 lg:grid-cols-3">
            {site.projects.map((project) => (
              <Reveal key={project.name}>
                <Card className="flex h-full flex-col gap-4">
                  <h3 className="text-lg font-semibold">{project.name}</h3>
                  <p className="text-sm text-muted">{project.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {project.tags.map((tag) => (
                      <Badge key={tag} label={tag} tone="muted" />
                    ))}
                  </div>
                </Card>
              </Reveal>
            ))}
          </div>
        </section>

        <section id="experience" className="flex flex-col gap-10">
          <SectionHeading
            eyebrow="Experience"
            title="Credibility at scale, delivered safely."
            description="Public-safe highlights across PayPal, Oracle, and TCS."
          />
          <div className="flex flex-col gap-6">
            {site.experience.map((role) => (
              <Reveal key={role.company}>
                <Card className="flex flex-col gap-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <h3 className="text-lg font-semibold">{role.role}</h3>
                      <p className="text-sm text-muted">{role.company}</p>
                    </div>
                    <span className="text-xs text-muted">{role.period}</span>
                  </div>
                  <ul className="space-y-2 text-sm text-muted">
                    {role.highlights.map((item) => (
                      <li key={item} className="flex items-start gap-2">
                        <span className="mt-1 h-1.5 w-1.5 rounded-full bg-accent" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </Card>
              </Reveal>
            ))}
          </div>
        </section>

        <section id="skills" className="flex flex-col gap-10">
          <SectionHeading
            eyebrow="Skills"
            title="Full-stack product systems."
            description="Design, frontend, and backend skills that connect end-to-end."
          />
          <div className="grid gap-6 lg:grid-cols-3">
            {site.skills.map((group) => (
              <Reveal key={group.group}>
                <Card className="flex flex-col gap-4">
                  <h3 className="text-lg font-semibold">{group.group}</h3>
                  <div className="flex flex-wrap gap-2">
                    {group.items.map((item) => (
                      <Badge key={item} label={item} tone="muted" />
                    ))}
                  </div>
                </Card>
              </Reveal>
            ))}
          </div>
        </section>

        <section id="contact" className="flex flex-col gap-8">
          <SectionHeading
            eyebrow="Contact"
            title={site.contact.headline}
            description={site.contact.subheadline}
          />
          <Card className="flex flex-col gap-6">
            <div className="flex flex-col gap-3 text-sm text-muted">
              <div>
                Email:{' '}
                <Link href={`mailto:${site.profile.email}`} className="text-text">
                  {site.profile.email}
                </Link>
              </div>
              <div>
                LinkedIn:{' '}
                <Link
                  href={site.profile.links.linkedin}
                  className="text-text"
                  target="_blank"
                  rel="noreferrer"
                >
                  {site.profile.links.linkedin}
                </Link>
              </div>
              <div>
                GitHub:{' '}
                <Link
                  href={site.profile.links.github}
                  className="text-text"
                  target="_blank"
                  rel="noreferrer"
                >
                  {site.profile.links.github}
                </Link>
              </div>
            </div>
            <div className="flex flex-wrap gap-3">
              <CTAButton href={`mailto:${site.profile.email}`} label="Email me" />
              <CopyButton value={site.profile.email} />
            </div>
          </Card>
        </section>
      </main>
    </div>
  );
}
