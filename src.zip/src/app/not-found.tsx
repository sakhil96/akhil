import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="flex min-h-screen items-center justify-center px-6">
      <div className="text-center">
        <div className="text-6xl font-semibold text-gradient">404</div>
        <h1 className="mt-4 text-2xl font-semibold">Page not found</h1>
        <p className="mt-2 text-sm text-muted">
          The signal trail ends here. Head back to the control room.
        </p>
        <Link
          href="/"
          className="mt-6 inline-flex items-center justify-center rounded-full border border-white/15 px-4 py-2 text-sm text-text hover:border-accent/50"
        >
          Return home
        </Link>
      </div>
    </div>
  );
}

