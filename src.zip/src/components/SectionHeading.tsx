type SectionHeadingProps = {
  eyebrow?: string;
  title: string;
  description?: string;
  align?: 'left' | 'center';
};

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = 'left',
}: SectionHeadingProps) {
  const alignment = align === 'center' ? 'text-center items-center' : 'text-left items-start';

  return (
    <div className={`flex flex-col gap-3 ${alignment}`}>
      {eyebrow ? (
        <span className="text-xs uppercase tracking-[0.2em] text-muted">{eyebrow}</span>
      ) : null}
      <h2 className="font-display text-3xl sm:text-4xl">{title}</h2>
      {description ? (
        <p className="max-w-2xl text-sm sm:text-base text-muted">{description}</p>
      ) : null}
    </div>
  );
}
