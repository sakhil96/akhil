import { Card } from '@/components/Card';
import { CTAButton } from '@/components/CTAButton';
import { Badge } from '@/components/Badge';

type TrophyCardProps = {
  title: string;
  tags: string[];
  bullets: string[];
  cta: { label: string; href: string };
};

export function TrophyCard({ title, tags, bullets, cta }: TrophyCardProps) {
  return (
    <Card className="relative overflow-hidden">
      <div className="absolute right-0 top-0 h-24 w-24 rounded-full bg-accent/20 blur-2xl" />
      <div className="relative flex h-full flex-col gap-4">
        <div className="flex flex-wrap gap-2">
          {tags.map((tag) => (
            <Badge key={tag} label={tag} tone="muted" />
          ))}
        </div>
        <h3 className="text-xl font-semibold">{title}</h3>
        <ul className="space-y-2 text-sm text-muted">
          {bullets.map((bullet) => (
            <li key={bullet} className="flex items-start gap-2">
              <span className="mt-1 h-1.5 w-1.5 rounded-full bg-accent" aria-hidden />
              <span>{bullet}</span>
            </li>
          ))}
        </ul>
        <CTAButton href={cta.href} label={cta.label} variant="ghost" className="mt-auto w-fit" />
      </div>
    </Card>
  );
}
