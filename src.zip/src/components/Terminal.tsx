'use client';

import { useMemo, useRef, useState } from 'react';
import { site } from '@/lib/site';

type TerminalEntry = {
  command: string;
  output: string[];
};

export function Terminal() {
  const [history, setHistory] = useState<TerminalEntry[]>([]);
  const [value, setValue] = useState('');
  const inputRef = useRef<HTMLInputElement | null>(null);

  const commandMap = useMemo(() => {
    return new Map(site.terminal.commands.map((cmd) => [cmd.command, cmd]));
  }, []);

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const trimmed = value.trim().toLowerCase();
    if (!trimmed) return;

    const command = commandMap.get(trimmed);
    setHistory((prev) => [
      ...prev,
      {
        command: trimmed,
        output: command
          ? command.output
          : ['Unknown command. Type `help` to see what is available.'],
      },
    ]);
    setValue('');
  };

  return (
    <div
      className="card-surface rounded-2xl border border-white/10 p-6 font-mono text-sm"
      onClick={() => inputRef.current?.focus()}
      role="region"
      aria-label="Interactive terminal"
    >
      <div className="flex items-center gap-2 text-xs text-muted">
        <span className="h-2 w-2 rounded-full bg-success" />
        <span className="h-2 w-2 rounded-full bg-warning" />
        <span className="h-2 w-2 rounded-full bg-accent" />
        <span className="ml-2">Inference terminal</span>
      </div>

      <div className="mt-4 space-y-4">
        <div className="text-muted">
          Type <span className="text-text">help</span> to explore the control room.
        </div>

        {history.map((entry, index) => (
          <div key={`${entry.command}-${index}`} className="space-y-2">
            <div className="text-text">
              <span className="text-accent">{site.terminal.prompt}</span> $
              <span className="ml-2">{entry.command}</span>
            </div>
            <div className="space-y-1 text-muted">
              {entry.output.map((line, lineIndex) => (
                <div key={`${entry.command}-${lineIndex}`}>{line}</div>
              ))}
            </div>
          </div>
        ))}

        <form onSubmit={handleSubmit} className="flex items-center gap-2">
          <span className="text-accent">{site.terminal.prompt}</span>
          <span>$</span>
          <label className="sr-only" htmlFor="terminal-input">
            Terminal input
          </label>
          <input
            id="terminal-input"
            ref={inputRef}
            value={value}
            onChange={(event) => setValue(event.target.value)}
            className="flex-1 bg-transparent text-text placeholder:text-muted focus:outline-none"
            placeholder="Type a command..."
            autoComplete="off"
          />
        </form>
      </div>
    </div>
  );
}
