'use client';

import Link from 'next/link';
import { site } from '@/lib/site';

export function Navbar() {
  const handleCommandPalette = () => {
    window.dispatchEvent(new CustomEvent('command-palette-open'));
  };

  return (
    <header className="sticky top-0 z-40 border-b border-white/5 bg-[rgba(7,9,15,0.85)] backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
        <Link href="/" className="font-display text-lg tracking-tight">
          {site.profile.name}
        </Link>
        <nav className="hidden items-center gap-5 text-sm text-muted md:flex">
          {site.sections.map((section) => (
            <Link key={section.id} href={`/#${section.id}`} className="hover:text-text">
              {section.label}
            </Link>
          ))}
        </nav>
        <button
          type="button"
          onClick={handleCommandPalette}
          className="rounded-full border border-white/10 px-3 py-2 text-xs text-muted hover:border-accent/50 hover:text-text"
          aria-label="Open command palette"
        >
          ⌘K
        </button>
      </div>
    </header>
  );
}
