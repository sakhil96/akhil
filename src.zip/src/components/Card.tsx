import { cn } from '@/lib/utils';
import type { ReactNode } from 'react';

type CardProps = {
  children: ReactNode;
  className?: string;
};

export function Card({ children, className }: CardProps) {
  return (
    <div className={cn('card-surface card-hover rounded-2xl p-6', className)}>
      {children}
    </div>
  );
}
