'use client';

import { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { site } from '@/lib/site';
import { cn } from '@/lib/utils';

type Action = {
  id: string;
  label: string;
  href: string;
  keywords?: string[];
};

export function CommandPalette() {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');

  const actions = useMemo<Action[]>(() => {
    const sectionActions = site.sections.map((section) => ({
      id: `section-${section.id}`,
      label: section.label,
      href: `/#${section.id}`,
      keywords: ['section', 'jump'],
    }));
    const caseStudyActions = site.caseStudies.map((study) => ({
      id: `case-${study.slug}`,
      label: study.title,
      href: study.href,
      keywords: study.tags,
    }));
    return [
      ...sectionActions,
      ...caseStudyActions,
      { id: 'contact', label: 'Contact', href: '/#contact', keywords: ['email'] },
    ];
  }, []);

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        setOpen(true);
      }
      if (event.key === 'Escape') {
        setOpen(false);
      }
    };
    const openHandler = () => setOpen(true);
    window.addEventListener('keydown', handler);
    window.addEventListener('command-palette-open', openHandler);
    return () => {
      window.removeEventListener('keydown', handler);
      window.removeEventListener('command-palette-open', openHandler);
    };
  }, []);

  useEffect(() => {
    if (!open) setQuery('');
  }, [open]);

  const filtered = actions.filter((action) => {
    const haystack = `${action.label} ${action.keywords?.join(' ') ?? ''}`.toLowerCase();
    return haystack.includes(query.toLowerCase());
  });

  const handleSelect = (href: string) => {
    setOpen(false);
    router.push(href);
  };

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
      onClick={() => setOpen(false)}
    >
      <div
        className="w-full max-w-xl rounded-2xl border border-white/10 bg-surface p-4 shadow-2xl"
        role="dialog"
        aria-modal="true"
        aria-label="Command palette"
        onClick={(event) => event.stopPropagation()}
      >
        <input
          autoFocus
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          className="w-full rounded-xl border border-white/10 bg-surface-strong px-4 py-3 text-sm text-text placeholder:text-muted focus:outline-none"
          placeholder="Jump to a section or case study..."
        />
        <div className="mt-4 space-y-2">
          {filtered.length === 0 ? (
            <div className="rounded-xl border border-white/5 bg-white/5 p-4 text-sm text-muted">
              No matches. Try "wins" or "case studies."
            </div>
          ) : (
            filtered.map((action) => (
              <button
                key={action.id}
                type="button"
                onClick={() => handleSelect(action.href)}
                className={cn(
                  'flex w-full items-center justify-between rounded-xl border border-transparent px-4 py-3 text-left text-sm text-text',
                  'hover:border-accent/40 hover:bg-accent/10',
                )}
              >
                <span>{action.label}</span>
                <span className="text-xs text-muted">{action.href}</span>
              </button>
            ))
          )}
        </div>
        <button
          type="button"
          onClick={() => setOpen(false)}
          className="mt-4 text-xs text-muted hover:text-text"
        >
          Press Esc to close
        </button>
      </div>
    </div>
  );
}
