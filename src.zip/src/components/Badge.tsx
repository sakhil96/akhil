import { cn } from '@/lib/utils';

type BadgeProps = {
  label: string;
  tone?: 'accent' | 'muted' | 'success' | 'warning';
  className?: string;
};

const toneStyles: Record<NonNullable<BadgeProps['tone']>, string> = {
  accent: 'border-accent/40 text-accent bg-accent/10',
  muted: 'border-white/10 text-muted bg-white/5',
  success: 'border-success/40 text-success bg-success/10',
  warning: 'border-warning/40 text-warning bg-warning/10',
};

export function Badge({ label, tone = 'accent', className }: BadgeProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full border px-3 py-1 text-xs font-medium tracking-wide',
        toneStyles[tone],
        className,
      )}
    >
      {label}
    </span>
  );
}
