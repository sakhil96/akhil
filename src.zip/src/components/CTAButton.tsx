import Link from 'next/link';
import { cn } from '@/lib/utils';

type CTAButtonProps = {
  href: string;
  label: string;
  variant?: 'primary' | 'ghost';
  className?: string;
};

export function CTAButton({ href, label, variant = 'primary', className }: CTAButtonProps) {
  return (
    <Link
      href={href}
      className={cn(
        'inline-flex items-center justify-center rounded-full px-4 py-2 text-sm font-semibold transition',
        variant === 'primary'
          ? 'bg-accent text-black shadow-glow hover:-translate-y-0.5'
          : 'border border-white/15 text-text hover:border-accent/50 hover:text-white',
        className,
      )}
    >
      {label}
    </Link>
  );
}
